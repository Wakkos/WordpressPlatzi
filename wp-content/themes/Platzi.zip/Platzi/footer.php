<footer class="footer">
    <strong>&copy; By Platzi</strong> <small>2015</small>
</footer>
<?php wp_footer(); ?>
</body>
</html>