<?php
    wp_nav_menu(
        array(
            'theme_location' => 'menu-header',
            'container'       => 'nav',
            'container_class' => 'nav',
            'menu_class'      => 'nav__list'
            )
        );
 ?>