<aside>
    <ul>
        <li>opción 1</li>
        <li>opción 2</li>
        <li>opción 3</li>
        <li>opción 4</li>
        <li>opción 5</li>
        <li>opción 6</li>
    </ul>
</aside>